@echo off
chcp 65001 >nul
title 교안봇 서버
echo.
echo  교안봇 서버를 시작합니다...
echo.
start http://localhost:3000
node "%~dp0server.js"
pause
