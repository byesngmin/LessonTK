// Custom Modal Utilities (Alert & Confirm Replacements)

// ------------------------------------------------------------------------







window.alert = window.showAlert;









// ── F1-2: 핵심개념 입력 팝업 ──
window.showKeyConceptsPrompt = function (title, defaultConcepts, onConfirm) {
    const defaults = Array.isArray(defaultConcepts) ? defaultConcepts.filter(Boolean) : [];

    // 5단 태그 감지 (교사카드 별점 연동 및 재사용 시)
    const tagged = [1,2,3,4,5].map(n => ({
        n,
        items: defaults.filter(k => k.startsWith(`[★${n}]`)).map(k => k.replace(`[★${n}]`, '').trim())
    }));
    const hasTagged = tagged.some(t => t.items.length > 0);
    const plainDefaults = hasTagged ? [] : defaults.filter(k => !/^\[★\d\]/.test(k));

    // 5단 UI 설정
    const TIERS = [
        { n: 5, stars: '⭐⭐⭐⭐⭐', label: '5점', desc: '풍부한 사례, 긴 Q&A (5.0x)', color: 'text-yellow-400', border: 'border-yellow-500/40', focus: 'focus:border-yellow-400' },
        { n: 4, stars: '⭐⭐⭐⭐', label: '4점', desc: '깊은 이해 요구 (3.5x)', color: 'text-orange-400', border: 'border-orange-500/40', focus: 'focus:border-orange-400' },
        { n: 3, stars: '⭐⭐⭐', label: '3점', desc: '핵심 개념 - 디폴트 (2.5x)', color: 'text-blue-400', border: 'border-blue-500/40', focus: 'focus:border-blue-400' },
        { n: 2, stars: '⭐⭐', label: '2점', desc: '부연 설명 (1.5x)', color: 'text-sky-300', border: 'border-sky-500/30', focus: 'focus:border-sky-300' },
        { n: 1, stars: '⭐', label: '1점', desc: '가벼운 리딩 (1.0x)', color: 'text-gray-400', border: 'border-gray-500/20', focus: 'focus:border-gray-400' },
    ];

    const tierInputsHTML = TIERS.map(t => {
        const val = tagged.find(x => x.n === t.n)?.items.join(', ') || '';
        return `
        <div class="flex items-start gap-2">
          <div class="shrink-0 pt-2 w-44">
            <span class="text-xs font-bold ${t.color} block leading-none">${t.stars}</span>
            <span class="text-[0.6rem] text-textMuted/70 block">${t.desc}</span>
          </div>
          <input type="text" id="kc-star${t.n}"
            value="${val.replace(/"/g, '&quot;')}"
            placeholder="쉼표로 구분 입력"
            class="flex-1 bg-black/30 border ${t.border} rounded-lg px-3 py-2 text-sm text-white ${t.focus} focus:outline-none transition-colors">
        </div>`;
    }).join('');

    const overlay = document.createElement('div');
    overlay.className = 'fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[9999] animate-fade-in';
    overlay.onclick = () => overlay.remove();
    overlay.innerHTML = `
        <div class="bg-[#1a1a2e] border border-white/10 rounded-2xl w-[520px] p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-y-auto" onclick="event.stopPropagation()">
            <!-- 헤더 -->
            <div class="flex items-center justify-between mb-4 shrink-0">
              <div class="flex items-center gap-3">
                <i class="ph-fill ph-lightbulb text-2xl text-accent"></i>
                <h3 class="font-bold text-white text-sm">${title}</h3>
              </div>
              <button id="kc-mode-toggle" class="text-[0.65rem] font-bold px-2.5 py-1.5 rounded-lg border transition-colors bg-white/5 border-white/10 text-textMuted hover:bg-accent/10 hover:border-accent/30 hover:text-accent flex items-center gap-1 shrink-0">
                <i class="ph-bold ph-star"></i> 중요도별 입력
              </button>
            </div>

            <!-- 기본 모드 -->
            <div id="kc-basic-mode">
              <p class="text-xs text-textMuted mb-3 leading-relaxed">이 차시에서 반드시 다뤄야 할 핵심 개념을 입력하세요.<br>쉼표(,)로 구분하며, 비워두면 AI가 자동 구성합니다.</p>
              <input type="text" id="kc-prompt-input" value="${plainDefaults.join(', ').replace(/"/g, '&quot;')}"
                placeholder="예: 게임 루프, 프레임 레이트, 델타 타임"
                class="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:border-accent transition-colors mb-4"
                onkeydown="if(event.key==='Enter'){document.getElementById('kc-prompt-ok').click();}">
            </div>

            <!-- 확장 모드 (5단 별점) -->
            <div id="kc-expanded-mode" class="hidden">
              <p class="text-xs text-textMuted mb-3 leading-relaxed">별점 중요도별로 키워드를 분리 입력하세요. 강사 카드 별점 기준과 동일합니다.</p>
              <div class="flex flex-col gap-3 mb-4">
                ${tierInputsHTML}
              </div>
            </div>

            <!-- 버튼 -->
            <div class="flex justify-end gap-2 shrink-0 mt-1">
              <button class="px-4 py-2 text-xs font-bold text-textLight bg-white/5 hover:bg-white/10 rounded-lg transition-colors" onclick="this.closest('.fixed').remove()">취소</button>
              <button id="kc-prompt-ok" class="px-4 py-2 text-xs font-bold text-white bg-accent hover:bg-accentHover rounded-lg transition-colors flex items-center gap-1">
                <i class="ph-bold ph-sparkle"></i> 생성
              </button>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);

    // 모드 토글
    let isExpanded = hasTagged;
    const toggleBtn = document.getElementById('kc-mode-toggle');
    const basicMode = document.getElementById('kc-basic-mode');
    const expandedMode = document.getElementById('kc-expanded-mode');

    if (isExpanded) {
        basicMode.classList.add('hidden');
        expandedMode.classList.remove('hidden');
        toggleBtn.innerHTML = '<i class="ph-bold ph-text-align-left"></i> 기본 입력';
        toggleBtn.classList.add('bg-accent/10', 'border-accent/30', 'text-accent');
        toggleBtn.classList.remove('bg-white/5', 'border-white/10', 'text-textMuted');
    } else {
        setTimeout(() => { const el = document.getElementById('kc-prompt-input'); if(el) el.focus(); }, 100);
    }

    toggleBtn.addEventListener('click', () => {
        isExpanded = !isExpanded;
        if (isExpanded) {
            basicMode.classList.add('hidden');
            expandedMode.classList.remove('hidden');
            toggleBtn.innerHTML = '<i class="ph-bold ph-text-align-left"></i> 기본 입력';
            toggleBtn.classList.add('bg-accent/10', 'border-accent/30', 'text-accent');
            toggleBtn.classList.remove('bg-white/5', 'border-white/10', 'text-textMuted');
        } else {
            basicMode.classList.remove('hidden');
            expandedMode.classList.add('hidden');
            toggleBtn.innerHTML = '<i class="ph-bold ph-star"></i> 중요도별 입력';
            toggleBtn.classList.remove('bg-accent/10', 'border-accent/30', 'text-accent');
            toggleBtn.classList.add('bg-white/5', 'border-white/10', 'text-textMuted');
        }
    });

    document.getElementById('kc-prompt-ok').onclick = () => {
        let concepts;
        if (isExpanded) {
            concepts = [];
            [5,4,3,2,1].forEach(n => {
                const el = document.getElementById(`kc-star${n}`);
                if (!el) return;
                const val = el.value.trim();
                if (val) {
                    val.split(',').map(s => s.trim()).filter(Boolean).forEach(s => concepts.push(`[★${n}]${s}`));
                }
            });
        } else {
            const raw = document.getElementById('kc-prompt-input').value.trim();
            concepts = raw ? raw.split(',').map(s => s.trim()).filter(Boolean) : [];
        }
        overlay.remove();
        if (typeof onConfirm === 'function') onConfirm(concepts);
    };
};

// 전역 클릭 감지 (드롭다운 외부 클릭 시 닫기)
document.addEventListener('click', (event) => {
    // 1. 데이터 관리 메뉴 (좌상단 설정쪽) 닫기
    const dataMenu = document.getElementById('data-manage-menu');
    const dataBtn = document.getElementById('btn-data-manage');

    if (dataMenu && !dataMenu.classList.contains('hidden') &&
        !dataMenu.contains(event.target) && (!dataBtn || !dataBtn.contains(event.target))) {
        dataMenu.classList.add('hidden');
        dataMenu.classList.remove('flex');
    }

    // 2. PDF 드롭다운 닫기
    const pdfMenu = document.getElementById('pdf-dropdown-menu');
    const pdfBtn = document.getElementById('pdf-dropdown-btn');

    if (pdfMenu && !pdfMenu.classList.contains('hidden') &&
        !pdfMenu.contains(event.target) && (!pdfBtn || !pdfBtn.contains(event.target))) {
        pdfMenu.classList.add('hidden');
        pdfMenu.classList.remove('flex');
    }

    // 3. 폴더 연동 드롭다운 닫기
    const folderMenu = document.getElementById('folder-dropdown-menu');
    const folderIndicator = document.getElementById('folder-connection-indicator');

    if (folderMenu && !folderMenu.classList.contains('hidden') &&
        !folderMenu.contains(event.target) && (!folderIndicator || !folderIndicator.contains(event.target))) {
        folderMenu.classList.add('hidden');
        folderMenu.classList.remove('flex');
    }
});

window.addEventListener('hashchange', handleRoute);



window.saveAndGoHome = function () {

    const rawView = document.getElementById('raw-view');

    if (rawView && !rawView.classList.contains('hidden')) {

        saveRawContent();

    }

    location.hash = '#overview';

};



function handleRoute() {

    try {

        const hash = window.location.hash;

        const overview = document.getElementById('overview-container');

        const editor = document.getElementById('editor-container');



        if (hash.startsWith('#editor')) {

            const parts = hash.split('/');

            const subjectId = parts[1] || 'subject_1';

            const moduleId = parts[2];

            openEditor(subjectId, moduleId);

            overview.classList.add('hidden');

            editor.classList.remove('hidden');

            closeDetailPanel();

        } else {

            renderOverview();

            overview.classList.remove('hidden');

            editor.classList.add('hidden');

        }

    } catch (e) {

        console.error("라우팅 오류:", e);

        window.showAlert("화면 전환 중 오류가 발생했습니다. 데이터가 손상되었을 수 있습니다.");

    }

}




// --- Overview UI Rendering ---



window.updateCourseTitle = function (inputEl) {
    let newTitle = inputEl.value.trim();
    if (!newTitle) newTitle = '새로운 과정';

    if (globalState.courseTitle !== newTitle) {
        globalState.courseTitle = newTitle;
        inputEl.value = newTitle;
        saveState();
    }
}



function renderOverviewLNB() {

    const list = document.getElementById('overview-lnb-list');

    if (!list) return;



    if (!Array.isArray(globalState.subjects) || globalState.subjects.length === 0) {
        list.className = 'flex-1 p-8 flex items-center justify-center'; // Make it centered container
        list.innerHTML = `
            <div class="flex flex-col items-center justify-center p-16 border-2 border-dashed border-white/10 rounded-2xl text-textMuted bg-black/20 w-full max-w-2xl mx-auto shadow-sm">
                <i class="ph-duotone ph-cards text-[5rem] mb-6 opacity-40 text-accent"></i>
                <h3 class="text-xl font-bold text-white mb-3">과정 목차가 텅 비어있습니다.</h3>
                <p class="text-sm mb-8 leading-relaxed text-center max-w-md">상단의 '새 교과 추가' 버튼을 눌러 첫 번째 교과를 만들고 커리큘럼 구성을 시작하세요.</p>
                <button onclick="createNewSubject()" class="px-6 py-3 flex items-center gap-2 rounded-xl bg-gradient-to-r from-accent to-accentHover text-white font-bold transition-all shadow-[0_4px_15px_rgba(124,91,245,0.4)] hover:-translate-y-1 hover:shadow-[0_8px_25px_rgba(124,91,245,0.6)]">
                    <i class="ph-bold ph-plus text-lg"></i> 첫 교과 추가하기
                </button>
            </div>`;
        return;
    }

    list.className = 'flex-1 overflow-y-auto p-4 md:p-6 flex flex-col gap-2 content-start editor-scroll relative z-0';

    list.innerHTML = globalState.subjects.map((subj, idx) => `
        <div class="bg-[#1e1e36] border border-white/8 rounded-xl flex items-center gap-4 px-4 py-3 group hover:border-accent/40 hover:bg-accent/[0.04] transition-all cursor-pointer overflow-hidden relative"
             draggable="true" data-subj-idx="${idx}"
             ondragstart="handleSubjDragStart(event, ${idx})"
             ondragover="handleSubjDragOver(event)"
             ondragenter="event.currentTarget.classList.add('border-accent','bg-accent/10')"
             ondragleave="event.currentTarget.classList.remove('border-accent','bg-accent/10')"
             ondrop="handleSubjDrop(event, ${idx})"
             ondragend="document.querySelectorAll('#overview-lnb-list > div').forEach(d=>d.classList.remove('border-accent','bg-accent/10'))"
             onclick="openSubjectDetail('${subj.id}')">
            <div class="absolute left-0 inset-y-0 w-[3px] bg-accent rounded-r opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>

            <!-- 드래그 핸들 -->
            <div class="w-6 h-6 flex items-center justify-center text-textMuted/40 hover:text-white cursor-grab active:cursor-grabbing shrink-0 transition-colors" title="드래그하여 순서 변경">
                <i class="ph-bold ph-dots-six-vertical text-base"></i>
            </div>

            <!-- 순번 뱃지 -->
            <div class="w-7 h-7 rounded-lg bg-accent/15 border border-accent/20 flex items-center justify-center font-bold text-accent text-xs shrink-0">
                ${idx + 1}
            </div>

            <!-- 제목 + 설명 (flex-1로 가로 팽창) -->
            <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2">
                    <span class="font-bold text-sm text-white truncate">${subj.title}</span>
                    ${subj.hasLevelTest ? `<span class="text-[0.6rem] font-bold bg-yellow-400/10 text-yellow-500 px-1.5 py-0.5 rounded flex items-center gap-1 shrink-0"><i class="ph-fill ph-crown text-[0.6rem]"></i> 퀘스트</span>` : ''}
                </div>
                <p class="text-xs text-textMuted truncate mt-0.5">${subj.description || '설명 없음'}</p>
            </div>

            <!-- 차시 수 뱃지 -->
            <div class="shrink-0 text-[0.65rem] font-bold bg-white/8 text-white/60 px-2.5 py-1 rounded-md flex items-center gap-1.5">
                <i class="ph-fill ph-file-text text-accent/70 text-[0.65rem]"></i> ${subj.lessons?.length || 0} 차시
            </div>

            <!-- 액션 버튼 (호버 시 노출) -->
            <div class="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                <button onclick="event.stopPropagation(); location.hash='#editor/${subj.id}'" class="w-7 h-7 flex items-center justify-center rounded-lg bg-white/10 hover:bg-accent text-white/70 hover:text-white transition-all" title="편집기로 이동">
                    <i class="ph-bold ph-pencil-simple text-xs"></i>
                </button>
                <button onclick="event.stopPropagation(); deleteSubject('${subj.id}')" class="w-7 h-7 flex items-center justify-center rounded-lg bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white transition-all" title="교과 삭제">
                    <i class="ph-bold ph-trash text-xs"></i>
                </button>
            </div>
        </div>
    `).join('');

}

// ── F1-1: 교과 순서 변경 DnD 핸들러 ──
let _subjDragIdx = -1;














function openSubjectDetail(id) {

    if (window.hasDragged) return;



    const panel = document.getElementById('overview-detail-panel');

    const subj = globalState.subjects.find(s => s.id === id);

    if (!subj) return;



    const lessonListHTML = (subj.lessons && subj.lessons.length > 0)

        ? subj.lessons.map((l, i) => `

                    <div class="flex gap-3 items-start mb-1 p-2 rounded-lg hover:bg-white/5 cursor-pointer transition-colors group" onclick="location.hash='#editor/${subj.id}/${l.id}'" title="해당 차시 편집기로 이동">

                        <span class="text-xs font-bold text-accent bg-accent/10 px-1.5 py-0.5 rounded shrink-0">${i + 1}</span>

                        <div>

                            <div class="text-sm font-bold text-white group-hover:text-accent transition-colors">${l.title}</div>

                            <div class="text-xs text-textMuted line-clamp-1">${l.description || '-'}</div>

                        </div>

                    </div>

                `).join('')

        : '<div class="text-xs text-textMuted bg-white/5 p-3 rounded">등록된 차시가 없습니다. 편집기에서 추가해주세요.</div>';



    panel.innerHTML = `

                <div class="p-5 border-b border-white/10 flex justify-between items-center bg-black/20 shrink-0">

                    <div class="flex items-center gap-2">

                        <i class="ph-duotone ph-info text-xl text-accent"></i>

                        <h2 class="font-bold text-lg text-white">교과 상세 정보</h2>

                    </div>

                    <button onclick="closeDetailPanel()" class="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/10 text-textMuted hover:text-white transition-colors">

                        <i class="ph-bold ph-x text-lg"></i>

                    </button>

                </div>

                

                <div class="p-6 flex-1 overflow-y-auto editor-scroll flex flex-col gap-6">

                    <div>

                        <label class="text-[0.65rem] font-bold text-accent uppercase tracking-widest mb-1.5 block">Subject Title</label>

                        <div class="text-xl font-bold text-white">${subj.title}</div>

                    </div>

                    

                    <div>

                        <label class="text-[0.65rem] font-bold text-accent uppercase tracking-widest mb-1.5 block">Description</label>

                        <div class="text-sm text-textLight leading-relaxed bg-white/5 p-4 rounded-xl border border-white/5">

                            ${subj.description}

                        </div>

                    </div>

                    

                    <div class="border-t border-white/5 pt-6">

                        <div class="flex justify-between items-end mb-4">

                            <label class="text-[0.65rem] font-bold text-accent uppercase tracking-widest">Lessons</label>

                            <span class="text-xs font-bold text-textMuted">총 ${subj.lessons?.length || 0}개</span>

                        </div>

                        <div class="bg-black/20 p-4 rounded-xl border border-white/5">

                            ${lessonListHTML}

                        </div>

                    </div>

                </div>

                

                <div class="p-5 border-t border-white/10 bg-black/20 shrink-0">

                    <button onclick="location.hash='#editor/${subj.id}'" class="w-full py-3.5 bg-gradient-to-r from-accent to-accentHover text-white font-bold rounded-xl shadow-[0_4px_15px_rgba(124,91,245,0.3)] hover:shadow-[0_6px_20px_rgba(124,91,245,0.5)] hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2">

                        <i class="ph-bold ph-pencil-simple text-lg"></i> 이 교과 편집기 열기

                    </button>

                </div>

            `;



    panel.classList.remove('translate-x-full');

}



function closeDetailPanel() {

    const panel = document.getElementById('overview-detail-panel');

    if (panel) panel.classList.add('translate-x-full');

}




// UI Helpers & Interactions

// ------------------------------------------------------------------------

function initHeaderScroll() {

    const header = document.getElementById('toolbar-scroll');

    if (!header) return;



    // 휠 스크롤 연동

    header.addEventListener('wheel', (e) => {

        if (e.deltaY !== 0) {

            e.preventDefault();

            header.scrollLeft += e.deltaY;

        }

    }, { passive: false });



    // 드래그 스크롤 연동

    let isDown = false;

    let startX;

    let scrollLeft;



    header.addEventListener('mousedown', (e) => {

        // 버튼 등을 클릭했을 때는 드래그 무시

        if (e.target.closest('button')) return;



        isDown = true;

        header.classList.add('cursor-grabbing');

        startX = e.pageX - header.offsetLeft;

        scrollLeft = header.scrollLeft;

    });



    header.addEventListener('mouseleave', () => {

        isDown = false;

        header.classList.remove('cursor-grabbing');

    });



    header.addEventListener('mouseup', () => {

        isDown = false;

        header.classList.remove('cursor-grabbing');

    });



    header.addEventListener('mousemove', (e) => {

        if (!isDown) return;

        e.preventDefault();

        const x = e.pageX - header.offsetLeft;

        const walk = (x - startX) * 1.5; // 드래그 속도 조절 (1.5배)

        header.scrollLeft = scrollLeft - walk;

    });

}

function toggleFolderDropdown() {
    const menu = document.getElementById('folder-dropdown-menu');
    if (menu) {
        menu.classList.toggle('hidden');
        menu.classList.toggle('flex');
    }
}

function togglePdfDropdown(event) {
    if (event) event.stopPropagation();
    const menu = document.getElementById('pdf-dropdown-menu');
    if (menu) {
        menu.classList.toggle('hidden');
        menu.classList.toggle('flex');
    }
}

// ------------------------------------------------------------------------


// Batch Generation Modal UI Control (Step 1 & 2)

// ------------------------------------------------------------------------

let batchUploadedFiles = []; // [{name, content}]



window.openBatchModal = function () {

    const modal = document.getElementById('batch-modal');

    const content = document.getElementById('batch-modal-content');



    // 현재 교과의 제목이 있다면 기본값으로 세팅

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    if (subj && subj.title !== '새로운 교과') {

        document.getElementById('batch-title').value = subj.title;

    }



    modal.classList.remove('hidden');

    // Allow display block to render before animating opacity

    requestAnimationFrame(() => {

        modal.classList.remove('opacity-0');

        content.classList.remove('scale-95');

        content.classList.add('scale-100');

    });

};



window.closeBatchModal = function () {

    const modal = document.getElementById('batch-modal');

    const content = document.getElementById('batch-modal-content');



    modal.classList.add('opacity-0');

    content.classList.remove('scale-100');

    content.classList.add('scale-95');



    setTimeout(() => {

        modal.classList.add('hidden');

    }, 300);

};



window.handleConceptEnter = function (e) {

    if (e.key === 'Enter') {

        e.preventDefault();

        addConceptField();

    }

};



window.addConceptField = function () {

    const list = document.getElementById('batch-concept-list');

    const count = list.children.length + 1;

    const newField = document.createElement('div');

    newField.className = 'flex gap-2 items-center concept-item group animate-fade-in';

    newField.innerHTML = `

                <div class="w-6 h-6 rounded bg-white/5 flex items-center justify-center text-textMuted text-xs font-bold shrink-0">${count}</div>

                <input type="text" class="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent transition-colors" placeholder="추가할 핵심 개념을 입력하세요" onkeydown="handleConceptEnter(event)">

                <button type="button" onclick="removeConceptField(this)" class="w-8 h-8 flex items-center justify-center rounded bg-white/5 hover:bg-red-500/20 text-textMuted hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100">

                    <i class="ph-bold ph-trash"></i>

                </button>

            `;

    list.appendChild(newField);



    // 새 입력 필드로 포커스 이동

    newField.querySelector('input').focus();



    // 넘버링 재정렬

    reindexConcepts();

};



window.removeConceptField = function (btn) {

    btn.closest('.concept-item').remove();

    reindexConcepts();

};



function reindexConcepts() {

    const list = document.getElementById('batch-concept-list');

    Array.from(list.children).forEach((item, idx) => {

        item.querySelector('div').innerText = idx + 1;

    });

}







function handleBatchFiles(files) {

    const MAX_FILES = 100;

    const fileArr = Array.from(files).filter(f => f.name.endsWith('.md') || f.name.endsWith('.txt'));

    if (fileArr.length === 0) {

        window.showAlert('지원하지 않는 파일 형식입니다. (.md, .txt 만 가능)');

        return;

    }

    const totalAfter = batchUploadedFiles.length + fileArr.length;

    if (totalAfter > MAX_FILES) {

        window.showAlert(`참조 파일은 최대 ${MAX_FILES}개까지 업로드할 수 있습니다.\n현재 ${batchUploadedFiles.length}개 + 추가 ${fileArr.length}개 = ${totalAfter}개`);

        return;

    }

    const readers = fileArr.map(file => new Promise(resolve => {

        const reader = new FileReader();

        reader.onload = e => resolve({ name: file.name, content: e.target.result });

        reader.readAsText(file);

    }));

    Promise.all(readers).then(results => {

        batchUploadedFiles = [...batchUploadedFiles, ...results];

        updateBatchFilePreview();

        document.getElementById('batch-file-input').value = '';

    });

}

function updateBatchFilePreview() {

    const count = batchUploadedFiles.length;

    if (count === 0) {

        document.getElementById('batch-file-preview').classList.add('hidden');

        return;

    }

    document.getElementById('batch-file-count').innerText = `${count}개 파일`;

    const listEl = document.getElementById('batch-file-list');

    listEl.innerHTML = batchUploadedFiles.map((f, i) =>

        `<div class="flex items-center gap-2 px-2 py-1 rounded bg-white/5 text-xs">` +

        `<span class="truncate text-textLight flex-1">${f.name}</span>` +

        `<button onclick="removeBatchFile(${i},event)" class="shrink-0 text-textMuted hover:text-red-400 transition-colors leading-none">✕</button>` +

        `</div>`

    ).join('');

    document.getElementById('batch-file-preview').classList.remove('hidden');

}

window.removeBatchFile = function (idx, e) {

    if (e) e.stopPropagation();

    batchUploadedFiles.splice(idx, 1);

    updateBatchFilePreview();

};

window.clearBatchFile = function (e) {

    if (e) e.stopPropagation();

    document.getElementById('batch-file-input').value = '';

    document.getElementById('batch-file-preview').classList.add('hidden');

    batchUploadedFiles = [];

};







// ------------------------------------------------------------------------
// [신규] 텍스트 드래그 시 Floating AI 수정 툴팁 렌더링 로직 추가
// ------------------------------------------------------------------------




// 툴팁의 버튼 클릭 시 강제 모드 전환 빛 포커싱


window.clearAISelection = function () {
    window.currentCapturedSelection = null;
    const displayRegion = document.getElementById('ai-selected-text-display');
    const displayContent = document.getElementById('ai-selected-text-content');
    if (displayRegion && displayContent) {
        displayContent.textContent = '';
        displayRegion.classList.add('hidden');
    }
    const sel = window.getSelection();
    if (sel) sel.removeAllRanges(); // 브라우저 자체 선택 영역도 해제
};

// 즉시 시작
document.addEventListener('DOMContentLoaded', () => {
    initSelectionHoverUI();
});
// ------------------------------------------------------------------------

// ------------------------------------------------------------------------


// Editor Functions & Config

// ------------------------------------------------------------------------

function openEditor(subjectId, targetModuleId = null) {

    currentSubjectId = subjectId;

    const subject = globalState.subjects.find(s => s.id === subjectId);

    if (subject) {

        document.getElementById('topic-input').value = subject.title;

        courseData = subject.lessons || [];

        if (!subject.mainQuest) {

            subject.mainQuest = {

                id: 'mainQuest', title: '👑 메인 퀘스트 (최종 과제)', description: '모든 일일 퀘스트를 종합한 최종 평가입니다.', status: 'waiting', content: null, images: {}, teacherNotes: [], qualityEvaluation: null

            };

        }

    } else {

        courseData = [];

        document.getElementById('topic-input').value = '새 교과';

    }

    currentEditingModuleId = null;

    document.getElementById('editor-content-area').innerHTML = `

                <div class="max-w-[800px] mx-auto p-12 flex flex-col items-center justify-center h-full text-center text-textMuted/50">

                    <i class="ph ph-file-text text-6xl mb-4 opacity-20"></i>

                    <h2 class="text-lg font-bold text-textMuted/60 mb-2">교안 편집 영역</h2>

                    <p class="text-sm leading-relaxed">좌측 목차에서 항목을 선택하거나 생성하면<br>이곳에 상세 내용이 렌더링됩니다.</p>

                </div>

            `;

    document.getElementById('ai-command-bar').classList.add('hidden');

    renderSidebar();



    if (targetModuleId) {

        const parsedId = targetModuleId === 'mainQuest' ? 'mainQuest' : parseInt(targetModuleId);

        setTimeout(() => viewModule(parsedId), 10);

    }

}



// CONTEXT_CORE moved to data.js



// API로 텍스트를 보내기 전, 보안 차단(WAF) 및 용량 초과를 방지하기 위한 정제 함수

// (안정화: 정규식 백트래킹 프리징 방어)







// =========================================================================
// [Phase F10] 캐시 보관함 (로컬 이미지 저장소) UI 컨트롤러
// =========================================================================

window.toggleCachePanel = function () {
    const root = document.getElementById('cache-panel');
    if (!root) return;

    // 히스토리 패널 열려있으면 닫기
    const histPanel = document.getElementById('history-panel');
    if (histPanel && !histPanel.classList.contains('hidden')) {
        histPanel.classList.add('hidden');
    }

    if (root.classList.contains('hidden')) {
        root.classList.remove('hidden');
        renderCacheList();
    } else {
        root.classList.add('hidden');
    }
};

window.renderCacheList = async function () {
    const listWrapper = document.getElementById('cache-list');
    const countBadge = document.getElementById('cache-count-badge');
    if (!listWrapper) return;

    try {
        const caches = await DBManager.getAllCaches();
        if (countBadge) countBadge.textContent = caches.length.toString();

        if (caches.length === 0) {
            listWrapper.innerHTML = `
                <div class="flex flex-col items-center justify-center p-6 text-center h-full opacity-50">
                    <i class="ph-fill ph-images text-2xl mb-2"></i>
                    <p class="text-xs">캐시된 이미지가 없습니다.</p>
                </div>
            `;
            return;
        }

        let html = '';
        for (const item of caches) {
            const dateStr = new Date(item.timestamp).toLocaleString();
            html += `
                <div class="group bg-black/20 border border-white/5 rounded-xl p-3 hover:bg-white/5 transition-colors relative overflow-hidden">
                    <div class="flex justify-between items-start mb-2">
                        <div class="flex-1 min-w-0 pr-2">
                            <h4 class="text-[0.75rem] font-bold text-white truncate" title="${item.keyword}">${item.keyword}</h4>
                            <p class="text-[0.6rem] text-textMuted mt-0.5">${dateStr} · ${item.format}</p>
                        </div>
                        <button onclick="deleteSingleCache('${item.keyword}')" class="w-6 h-6 flex items-center justify-center rounded bg-rose-500/10 hover:bg-rose-500/30 text-rose-400 opacity-0 group-hover:opacity-100 transition-all shrink-0">
                            <i class="ph-bold ph-trash text-xs"></i>
                        </button>
                    </div>
                    <div class="aspect-video bg-black/40 rounded flex items-center justify-center overflow-hidden border border-white/5">
                        <img src="${item.base64}" class="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" alt="캐시 이미지">
                    </div>
                </div>
            `;
        }
        listWrapper.innerHTML = html;

    } catch (e) {
        console.error("캐시 렌더링 오류:", e);
        listWrapper.innerHTML = `<p class="text-xs text-rose-400 p-4">캐시를 불러오는 중 오류가 발생했습니다.</p>`;
    }
};

window.deleteSingleCache = async function (keyword) {
    if (!confirm(`'${keyword}' 캐시를 삭제하시겠습니까?`)) return;
    try {
        await DBManager.deleteCache(keyword);
        renderCacheList(); // 리스트 갱신
        if (window.showToast) window.showToast(`캐시가 삭제되었습니다.`, 'success');
    } catch (e) {
        if (window.showToast) window.showToast(`캐시 삭제 실패!`, 'error');
    }
};

window.clearAllImageCaches = async function () {
    if (!confirm('경고: 로컬 시스템에 저장된 모든 이미지 캐시를 영구적으로 삭제합니다. 진행하시겠습니까?')) return;
    try {
        await DBManager.clearAllCaches();
        renderCacheList();
        if (window.showToast) window.showToast(`모든 이미지 캐시가 완전히 삭제되었습니다.`, 'success');
    } catch (e) {
        if (window.showToast) window.showToast(`캐시 전체 초기화 실패!`, 'error');
    }
};



// ------------------------------------------------------------------------

// =========================================================================
// [Phase UX-1] Editor Loading UI (Skeleton & Typing Animation) Manager
// =========================================================================

window.EditorLoading = {
    intervalId: null,
    phrases: [],
    currentIdx: 0,
    show: function (messages = ["AI가 상세 교안을 작성하고 있습니다..."]) {
        const loadingEl = document.getElementById('editor-loading');
        const textEl = document.getElementById('editor-loading-text');
        if (!loadingEl || !textEl) return;

        loadingEl.classList.remove('hidden');
        loadingEl.style.display = 'flex';
        loadingEl.style.opacity = '1';

        this.phrases = Array.isArray(messages) ? messages : [messages];
        this.currentIdx = 0;

        if (this.phrases.length > 0) {
            textEl.textContent = this.phrases[0];
            textEl.style.opacity = '1';
        }

        if (this.phrases.length > 1) {
            if (this.intervalId) clearInterval(this.intervalId);
            this.intervalId = setInterval(() => {
                this.currentIdx = (this.currentIdx + 1) % this.phrases.length;

                // Text fade rotation
                textEl.style.opacity = '0';
                setTimeout(() => {
                    textEl.textContent = this.phrases[this.currentIdx];
                    textEl.style.opacity = '1';
                }, 300);
            }, 3000);
        }
    },
    hide: function () {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }

        const loadingEl = document.getElementById('editor-loading');
        if (loadingEl) {
            loadingEl.style.opacity = '0';
            setTimeout(() => {
                loadingEl.style.display = 'none';
                loadingEl.classList.add('hidden');
            }, 300);
        }
    }
};

// =========================================================================
// Command Palette (Ctrl+K / Cmd+K)
// =========================================================================
(function initCommandPalette() {
    const overlay = document.getElementById('command-palette-overlay');
    const palette = document.getElementById('command-palette');
    const input = document.getElementById('command-palette-input');
    const list = document.getElementById('command-palette-list');

    if (!overlay || !palette || !input || !list) return;

    function resolveVolumeDirection(direction) {
        if (typeof VOLUME_PRESETS !== 'undefined' && VOLUME_PRESETS && VOLUME_PRESETS[direction]) {
            return direction;
        }
        if (direction === 'increase') return 'longer';
        if (direction === 'decrease') return 'shorter';
        return direction;
    }

    const commands = [
        { label: '교안 생성', category: '생성', icon: 'ph-sparkle', action: () => window.promptAndGenerateModule() },
        { label: '메인 퀘스트 생성', category: '생성', icon: 'ph-crown-simple', action: () => window.promptAndGenerateMainQuest() },
        { label: '일괄 생성', category: '생성', icon: 'ph-stack', action: () => window.startBatchGeneration() },
        { label: '문체 변환', category: '편집', icon: 'ph-arrows-left-right', action: () => window.showFormatConvertModal() },
        { label: '분량 늘리기', category: '편집', icon: 'ph-text-a-underline', action: () => window.applyVolumeControl(resolveVolumeDirection('increase')) },
        { label: '분량 줄이기', category: '편집', icon: 'ph-text-a-strikethrough', action: () => window.applyVolumeControl(resolveVolumeDirection('decrease')) },
        { label: '품질 평가', category: '품질', icon: 'ph-shield-check', action: () => window.runModuleQualityEvaluation() },
        { label: '품질 개선', category: '품질', icon: 'ph-magic-wand', action: () => window.runModuleQualityRefinement() },
        { label: 'MD 내보내기 (전체)', category: '내보내기', icon: 'ph-download-simple', action: () => exportAllModules() },
        { label: 'PDF 내보내기 (현재 차시)', category: '내보내기', icon: 'ph-file-pdf', action: () => (window.exportToPDF ? exportToPDF() : null) },
        { label: 'PDF 내보내기 (현재 교과)', category: '내보내기', icon: 'ph-books', action: () => (window.exportSubjectToPDF ? exportSubjectToPDF() : null) },
        { label: '설정 열기', category: '시스템', icon: 'ph-gear-six', action: () => (window.openSettingsPanel ? openSettingsPanel() : null) }
    ];

    let filteredCommands = commands.slice();
    let selectedIndex = 0;
    let isOpen = false;

    function escapeHtml(text) {
        return String(text).replace(/[&<>"']/g, (ch) => (
            {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;'
            }[ch]
        ));
    }

    function syncSelectionIntoView() {
        const selectedEl = list.querySelector(`li[data-index="${selectedIndex}"]`);
        if (selectedEl) selectedEl.scrollIntoView({ block: 'nearest' });
    }

    function renderList() {
        if (filteredCommands.length === 0) {
            list.innerHTML = `
                <li class="px-3 py-5 text-sm text-center text-white/50">
                    결과 없음
                </li>
            `;
            return;
        }

        list.innerHTML = filteredCommands.map((command, index) => {
            const isSelected = index === selectedIndex;
            const selectedClass = isSelected
                ? 'bg-accent/20 border-accent/40'
                : 'bg-white/[0.02] border-transparent hover:bg-white/10';

            return `
                <li data-index="${index}" class="flex items-center justify-between gap-3 px-3 py-2 rounded-lg border ${selectedClass} cursor-pointer transition-colors">
                    <div class="flex items-center gap-2.5 min-w-0">
                        <i class="ph-bold ${command.icon} text-base text-accent shrink-0"></i>
                        <span class="text-sm font-medium text-white truncate">${escapeHtml(command.label)}</span>
                    </div>
                    <span class="shrink-0 px-2 py-0.5 text-[0.65rem] font-bold rounded-full bg-white/10 text-white/70 border border-white/10">
                        ${escapeHtml(command.category)}
                    </span>
                </li>
            `;
        }).join('');
    }

    function openPalette() {
        isOpen = true;
        overlay.classList.remove('hidden');
        palette.classList.remove('hidden');

        input.value = '';
        filteredCommands = commands.slice();
        selectedIndex = 0;
        renderList();

        setTimeout(() => {
            input.focus();
            input.select();
        }, 0);
    }

    function closePalette() {
        isOpen = false;
        overlay.classList.add('hidden');
        palette.classList.add('hidden');
        input.blur();
    }

    function togglePalette() {
        if (isOpen) {
            closePalette();
        } else {
            openPalette();
        }
    }

    function updateFilter(keyword) {
        const normalized = (keyword || '').trim().toLowerCase();
        filteredCommands = normalized
            ? commands.filter((command) => command.label.toLowerCase().includes(normalized))
            : commands.slice();

        selectedIndex = filteredCommands.length > 0 ? 0 : -1;
        renderList();
    }

    function moveSelection(step) {
        if (filteredCommands.length === 0) return;
        selectedIndex = (selectedIndex + step + filteredCommands.length) % filteredCommands.length;
        renderList();
        syncSelectionIntoView();
    }

    function executeSelected() {
        if (selectedIndex < 0 || selectedIndex >= filteredCommands.length) return;
        const command = filteredCommands[selectedIndex];
        closePalette();

        try {
            command.action();
        } catch (error) {
            console.error('[Command Palette] 명령 실행 오류:', error);
            if (window.showAlert) {
                window.showAlert(`명령 실행 중 오류가 발생했습니다.\n${error.message || error}`);
            }
        }
    }

    overlay.addEventListener('click', closePalette);

    list.addEventListener('click', (event) => {
        const target = event.target.closest('li[data-index]');
        if (!target) return;
        selectedIndex = Number(target.dataset.index);
        executeSelected();
    });

    list.addEventListener('mousemove', (event) => {
        const target = event.target.closest('li[data-index]');
        if (!target) return;
        const hoveredIndex = Number(target.dataset.index);
        if (Number.isNaN(hoveredIndex) || hoveredIndex === selectedIndex) return;
        selectedIndex = hoveredIndex;
        renderList();
    });

    input.addEventListener('input', (event) => {
        updateFilter(event.target.value);
    });

    input.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            moveSelection(1);
            return;
        }

        if (event.key === 'ArrowUp') {
            event.preventDefault();
            moveSelection(-1);
            return;
        }

        if (event.key === 'Enter') {
            event.preventDefault();
            executeSelected();
            return;
        }

        if (event.key === 'Escape') {
            event.preventDefault();
            closePalette();
        }
    });

    document.addEventListener('keydown', (event) => {
        const isToggleShortcut = (event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k';
        if (isToggleShortcut) {
            event.preventDefault();
            togglePalette();
            return;
        }

        if (!isOpen) return;

        if (event.key === 'Escape') {
            event.preventDefault();
            closePalette();
            return;
        }

        if (event.key === 'ArrowDown') {
            event.preventDefault();
            moveSelection(1);
            return;
        }

        if (event.key === 'ArrowUp') {
            event.preventDefault();
            moveSelection(-1);
            return;
        }

        if (event.key === 'Enter' && document.activeElement !== input) {
            event.preventDefault();
            executeSelected();
        }
    });

    window.openCommandPalette = openPalette;
    window.closeCommandPalette = closePalette;
    window.toggleCommandPalette = togglePalette;
})();
