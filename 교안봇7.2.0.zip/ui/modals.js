window.showToast = function (message, type = 'success') {
    const toast = document.createElement('div');
    // type에 따른 색상 및 아이콘 설정
    const bgClass = type === 'error' ? 'bg-red-500' : type === 'warning' ? 'bg-amber-500' : 'bg-emerald-500';
    const iconClass = type === 'error' ? 'ph-warning-octagon' : type === 'warning' ? 'ph-warning' : 'ph-check-circle';

    toast.className = `fixed bottom-6 right-6 z-[9999] ${bgClass} text-white px-5 py-3 rounded-lg shadow-xl flex items-center gap-3 text-sm font-bold animate-fade-in-up transition-opacity duration-300`;
    toast.innerHTML = `
        <i class="ph-fill ${iconClass} text-xl"></i>
        <span>${message}</span>
    `;

    document.body.appendChild(toast);

    // 3초 뒤 페이드아웃 후 제거
    setTimeout(() => {
        toast.classList.replace('opacity-100', 'opacity-0'); // 만약 기존 opacity 유틸이 있다면 사용, 없으면 직접 style 제어
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
};

window.showAlert = function (message) {

    const overlay = document.createElement('div');

    overlay.className = 'fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[9999] animate-fade-in';

    overlay.onclick = () => overlay.remove();

    overlay.innerHTML = `

                <div class="bg-[#1a1a2e] border border-white/10 rounded-2xl w-[320px] p-6 shadow-2xl flex flex-col items-center text-center" onclick="event.stopPropagation()">

                    <div class="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center mb-4">

                        <i class="ph-fill ph-info text-2xl text-accent"></i>

                    </div>

                    <p class="text-sm text-textLight mb-6 whitespace-pre-wrap">${message}</p>

                    <button class="w-full px-4 py-2.5 text-sm font-bold text-white bg-accent hover:bg-accentHover rounded-xl transition-colors" onclick="this.closest('.fixed').remove()">확인</button>

                </div>

            `;

    document.body.appendChild(overlay);

};

window.showConfirm = function (message, onConfirm) {

    const overlay = document.createElement('div');

    overlay.className = 'fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[9999] animate-fade-in';

    overlay.onclick = () => overlay.remove();

    overlay.innerHTML = `

                <div class="bg-[#1a1a2e] border border-white/10 rounded-2xl w-[320px] p-6 shadow-2xl flex flex-col" onclick="event.stopPropagation()">

                    <div class="flex items-center gap-3 mb-4">

                        <i class="ph-fill ph-warning-circle text-2xl text-yellow-400"></i>

                        <h3 class="font-bold text-white text-sm">확인</h3>

                    </div>

                    <p class="text-sm text-textMuted mb-6 leading-relaxed whitespace-pre-wrap">${message}</p>

                    <div class="flex justify-end gap-2">

                        <button class="px-4 py-2 text-xs font-bold text-textLight bg-white/5 hover:bg-white/10 rounded-lg transition-colors" onclick="this.closest('.fixed').remove()">취소</button>

                        <button class="px-4 py-2 text-xs font-bold text-white bg-red-500/80 hover:bg-red-500 rounded-lg transition-colors" id="btn-confirm-ok">삭제</button>

                    </div>

                </div>

            `;

    document.body.appendChild(overlay);



    document.getElementById('btn-confirm-ok').onclick = () => {

        overlay.remove();

        if (typeof onConfirm === 'function') onConfirm();

    };

};

window.showModal = function (title, contentHTML) {

    const overlay = document.createElement('div');

    overlay.className = 'fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[9998] animate-fade-in';

    overlay.onclick = () => overlay.remove();

    overlay.innerHTML = `

                <div class="bg-[#1a1a2e] border border-white/10 rounded-2xl w-[800px] max-w-[90vw] max-h-[85vh] shadow-2xl flex flex-col" onclick="event.stopPropagation()">

                    <div class="flex items-center justify-between p-5 border-b border-white/10 shrink-0">

                        <h3 class="font-bold text-white text-lg flex items-center gap-2"><i class="ph-fill ph-book-open-text text-accent"></i> ${title}</h3>

                        <button class="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/10 text-textMuted hover:text-white transition-colors" onclick="this.closest('.fixed').remove()">

                            <i class="ph-bold ph-x text-lg"></i>

                        </button>

                    </div>

                    <div class="p-6 overflow-y-auto editor-scroll flex-1 text-sm bg-bgEditor markdown-body rounded-b-2xl">

                        ${contentHTML}

                    </div>

                </div>

            `;

    document.body.appendChild(overlay);

};
