window.validateCurriculumFormat = function (markdown = '') {
    const content = typeof markdown === 'string' ? markdown : '';

    // 본문 번호 목록 허용 여부(헤딩 라인은 제외)
    const numberedLines = content.match(/^(?!\s*#)\s*\d+\.\s+/gm) || [];
    const pendingImageTags = content.match(/<!--\s*\[IMG:\s*"?[^"\]]+"?\]\s*-->/g) || [];
    const lineCount = content.split('\n').length;
    const firstL1Heading = content.match(/^#\s+.+/m);
    const l1IconMissing = !!firstL1Heading && !/[\u{1f300}-\u{1f9ff}\u2600-\u27bf]/u.test(firstL1Heading[0]);
    const l2NumberedHeadings = (content.match(/^##\s+\d+\.\s/gm) || []).length;
    const l3MissingSymbol = (content.match(/^###\s+(?!\s*\u25a0)/gm) || []).length;
    const l4HeadingLines = content.match(/^####\s+.*/gm) || [];
    const l4MissingSymbol = l4HeadingLines.filter((line) => !/\u25a3/.test(line)).length;
    const markdownImages = content.match(/^!\[.*?\]\((?!local:|data:image)/gm) || [];

    // 정규식 키워드는 유니코드 이스케이프를 사용해 인코딩 환경 영향을 줄임
    const hasOverviewHeading = /^(?:##|###|####)\s*(?:\d+\.\s*)?.*(?:\uac1c\uc694|overview)/im.test(content);
    const hasObjectivesHeading = /^(?:##|###|####)\s*(?:\d+\.\s*)?.*(?:\ud559\uc2b5\s*\ubaa9\ud45c|learning\s*objectives?)/im.test(content);

    const warnings = [];
    const errors = [];

    if (l1IconMissing) {
        errors.push('L1 제목(#)에 아이콘(이모지)이 없습니다. 예: # \ud83d\udcdd 제목');
    }
    if (l2NumberedHeadings > 0) {
        errors.push('L2 헤딩(##)에 번호 매기기가 사용되었습니다. ## 제목 형식으로 수정하세요.');
    }
    if (numberedLines.length > 3) {
        warnings.push(`번호형 본문 목록이 ${numberedLines.length}개로 많습니다. 본문 병렬 나열은 '-' 불릿 사용을 권장합니다.`);
    }
    if (l3MissingSymbol > 0) {
        warnings.push(`L3 헤딩(###)에 \u25a0 기호가 없는 항목이 ${l3MissingSymbol}개 있습니다. ### \u25a0 세부개념 형식을 사용하세요.`);
    }
    if (l4MissingSymbol > 0) {
        warnings.push(`L4 헤딩(####)에 \u25a3 기호가 없는 항목이 ${l4MissingSymbol}개 있습니다.`);
    }
    if (lineCount < 700) {
        warnings.push(`교안 분량이 ${lineCount}줄로 기준(700줄)보다 부족합니다.`);
    }
    if (lineCount > 1000) {
        warnings.push(`교안 분량이 ${lineCount}줄로 권장 최대(1,000줄)를 초과합니다.`);
    }
    if (markdownImages.length > 0) {
        warnings.push(`일반 마크다운 이미지 형식(![])이 ${markdownImages.length}개 있습니다. HTML <p align=center><img> 형식을 권장합니다.`);
    }
    if (pendingImageTags.length > 0) {
        warnings.push(`미처리 이미지 태그가 ${pendingImageTags.length}개 남아 있습니다.`);
    }
    if (!hasOverviewHeading) {
        errors.push('개요(## ... 개요) 섹션 헤딩이 없습니다.');
    }
    if (!hasObjectivesHeading) {
        errors.push('학습 목표(## ... 학습 목표) 섹션 헤딩이 없습니다.');
    }

    return {
        isValid: errors.length === 0 && warnings.length === 0,
        errors,
        warnings,
        metrics: {
            lineCount,
            l1IconMissing,
            l2NumberedHeadings,
            l3MissingSymbol,
            l4MissingSymbol,
            markdownImages: markdownImages.length,
            numberedLines: numberedLines.length,
            pendingImageTags: pendingImageTags.length,
            hasOverviewHeading,
            hasObjectivesHeading
        }
    };
};

async function evaluateCurriculumQuality(mod, options = {}) {
    if (!mod || !mod.content) {
        throw new Error('No module content to evaluate.');
    }

    const persist = options.persist !== false;
    const source = options.source || 'manual';
    const quality = await requestCurriculumQualityEvaluation(mod, mod.content, source);

    if (persist) {
        mod.qualityEvaluation = quality;
        await saveState();
    }
    if (typeof window.renderQualityEvaluationBanner === 'function') {
        window.renderQualityEvaluationBanner(mod, { toast: !!options.toast, forceToast: !!options.forceToast });
    }
    return quality;
}

window.checkModuleCompleteness = function (content) {
    if (!content) return { overview: false, objectives: false, examples: false, quiz: false, images: false };

    // 개요 섹션 존재 여부
    const hasOverview = /^(?:##|###|####)\s*(?:\d+\.\s*)?.*(?:\uac1c\uc694|overview)/im.test(content);

    // 학습목표 섹션 존재 여부
    const hasObjectives = /^(?:##|###|####)\s*(?:\d+\.\s*)?.*(?:\ud559\uc2b5\s*\ubaa9\ud45c|learning\s*objectives?)/im.test(content);

    // 사례/예시 섹션 존재 여부
    const hasExamples = /^(?:##|###|####)\s*(?:\d+\.\s*)?.*(?:\uc0ac\ub840|\uc608\uc2dc|\uc2e4\ubb34\s*\uc0ac\ub840|\ucf00\uc774\uc2a4|example|case\s*study)/im.test(content);

    // 퀴즈/실습 섹션 존재 여부
    const hasQuiz = /^(?:##|###|####)\s*(?:\d+\.\s*)?.*(?:\ud034\uc988|\uc2e4\uc2b5|\uae30\ubcf8\s*\uc2e4\uc2b5|\uc2ec\ud654|quiz|practice|exercise)/im.test(content);

    // 실제 이미지 존재 여부 (local: 참조 또는 <img, 미처리 태그 제외)
    const hasImages = /!\[.*?\]\(local:[^\)]+\)|!\[.*?\]\(data:image/i.test(content)
        || /<img\s/i.test(content.replace(/<!--[\s\S]*?-->/g, ''));

    return { overview: hasOverview, objectives: hasObjectives, examples: hasExamples, quiz: hasQuiz, images: hasImages };
};
