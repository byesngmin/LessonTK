// 교안봇 로컬 서버 - Naver API CORS 프록시 + HTML 서빙
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = 3000;

const server = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url, true);

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');

    if (req.method !== 'OPTIONS') {
        console.log(`[${new Date().toLocaleTimeString()}] ${req.method} ${req.url}`);
    }

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    // Naver 이미지 검색 프록시
    if (parsedUrl.pathname === '/api/naver-image') {
        const clientId = req.headers['x-naver-client-id'];
        const clientSecret = req.headers['x-naver-client-secret'];
        const query = parsedUrl.query.query || '';
        const display = parsedUrl.query.display || '3';
        const sort = parsedUrl.query.sort || 'sim';

        if (!clientId || !clientSecret) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Missing Naver credentials' }));
            return;
        }

        const naverPath = `/v1/search/image?query=${encodeURIComponent(query)}&display=${display}&sort=${sort}`;
        const options = {
            hostname: 'openapi.naver.com',
            path: naverPath,
            method: 'GET',
            headers: {
                'X-Naver-Client-Id': clientId,
                'X-Naver-Client-Secret': clientSecret
            }
        };

        const proxyReq = https.request(options, (proxyRes) => {
            res.writeHead(proxyRes.statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
            proxyRes.pipe(res);
        });
        proxyReq.on('error', (e) => {
            res.writeHead(502, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: e.message }));
        });
        proxyReq.end();
        return;
    }

    // 이미지 프록시 (한국 사이트 CORS 우회)
    if (parsedUrl.pathname === '/api/image-proxy') {
        const targetUrl = parsedUrl.query.url;
        if (!targetUrl) {
            res.writeHead(400);
            res.end('Missing url param');
            return;
        }
        try {
            const parsed = new URL(targetUrl);
            const isHttps = parsed.protocol === 'https:';
            const client = isHttps ? https : http;
            const options = {
                hostname: parsed.hostname,
                path: parsed.pathname + parsed.search,
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36',
                    'Referer': parsed.origin
                }
            };
            const proxyReq = client.request(options, (proxyRes) => {
                const contentType = proxyRes.headers['content-type'] || 'image/jpeg';
                res.writeHead(proxyRes.statusCode, { 'Content-Type': contentType });
                proxyRes.pipe(res);
            });
            proxyReq.on('error', (e) => {
                res.writeHead(502);
                res.end(e.message);
            });
            proxyReq.end();
        } catch (e) {
            res.writeHead(400);
            res.end('Invalid URL');
        }
        return;
    }

    // 정적 파일 서빙 (js, css, 이미지 등)
    const MIME = {
        '.html': 'text/html; charset=utf-8',
        '.js':   'application/javascript; charset=utf-8',
        '.css':  'text/css; charset=utf-8',
        '.json': 'application/json; charset=utf-8',
        '.png':  'image/png',
        '.jpg':  'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.gif':  'image/gif',
        '.svg':  'image/svg+xml',
        '.ico':  'image/x-icon',
        '.woff': 'font/woff',
        '.woff2':'font/woff2',
    };

    const reqPath = parsedUrl.pathname === '/' ? '/index.html' : parsedUrl.pathname;
    const filePath = path.join(__dirname, reqPath);
    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME[ext] || 'application/octet-stream';

    fs.readFile(filePath, (err, data) => {
        if (err) {
            if (parsedUrl.pathname === '/') {
                res.writeHead(404);
                res.end('index.html not found.');
            } else {
                res.writeHead(404);
                res.end(`File not found: ${reqPath}`);
            }
            return;
        }
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(data);
    });
});

server.listen(PORT, () => {
    console.log('\n✅ 교안봇 서버 실행 중');
    console.log(`   브라우저: http://localhost:${PORT}`);
    console.log('   종료: Ctrl+C\n');
});
