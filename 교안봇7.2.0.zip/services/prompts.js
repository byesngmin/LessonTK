function cleanForAPI(text) {

    if (!text) return "";

    // 1. 이벤트 핸들러 제거

    let cleaned = text.replace(/on[a-z]+="[^"]*"/gi, "");

    // 2. Base64 이미지 데이터 치환 (백트래킹 방지 O(N) 정규식)

    cleaned = cleaned.replace(/data:image\/[^;]+;base64,[^"'\s\)>]+/gi, "[이미지 데이터 생략]");

    return cleaned;

}

function buildTaskContext(taskScope, additionalContext = "") {

    let systemInstruction = "";

    let userPrompt = "";

    // ── Phase 5 헬퍼: 전체 규칙 빌더 ──
    // Phase P0~P4의 모든 규칙을 하나의 문자열로 빌드
    function buildFullRules(keyConcepts) {
        const r = CONTEXT_CORE.rules;
        let rules = [
            `[Notion 참조 문서 — 최우선 열람 필수] 교안 작성 전에 아래 두 Notion 문서를 반드시 먼저 읽고, 서식 규칙과 예시를 준수하세요:\n서식 규칙 문서: ${NOTION_CONVENTION_URL}\n교안 예시 문서: ${NOTION_EXAMPLE_URL}`,
            r.priority_rules,
            r.body_lists,
            r.numbering_usage,
            r.element_definitions,
            r.glossary_terms,
            r.markdown_structure,
            r.image_tags,
            r.tone,
            r.heading_hierarchy,
            r.semantic_icons,
            r.indentation,
            r.text_emphasis,
            r.evidence_based,
            r.table_html_style,
            r.spacing,
            r.formatting_workflow
        ].filter(Boolean).map(rule => `- ${rule}`).join('\n');

        // 핵심개념 조건부 주입 (요청#3 선반영) + ## 최소치 동적 지정
        if (keyConcepts && keyConcepts.length > 0) {
            // 5단 별점 태그 파싱: [★1]~[★5] 접두사 감지
            const star = {};
            for (let n = 1; n <= 5; n++) {
                star[n] = keyConcepts.filter(k => k.startsWith(`[★${n}]`)).map(k => k.replace(`[★${n}]`, '').trim());
            }
            const plain = keyConcepts.filter(k => !/^\[★\d\]/.test(k));
            const hasWeighted = [1,2,3,4,5].some(n => star[n].length > 0);

            if (hasWeighted) {
                if (star[5].length > 0) rules += `\n- [⭐⭐⭐⭐⭐ 최우선 심화] 다음 개념은 풍부한 사례와 긴 Q&A로 상세히 다루세요: ${star[5].join(', ')}`;
                if (star[4].length > 0) rules += `\n- [⭐⭐⭐⭐ 심층 이해] 다음 개념을 깊이 있게 다루며 별도 ## 섹션을 구성하세요: ${star[4].join(', ')}`;
                if (star[3].length > 0) rules += `\n- [⭐⭐⭐ 핵심 개념] 다음 개념을 반드시 포함하여 교안을 구성하세요: ${star[3].join(', ')}`;
                if (star[2].length > 0) rules += `\n- [⭐⭐ 부연 설명] 다음 개념을 적절히 언급하며 설명하세요: ${star[2].join(', ')}`;
                if (star[1].length > 0) rules += `\n- [⭐ 가벼운 언급] 지면이 허락하면 다음 개념을 간략히 언급하세요: ${star[1].join(', ')}`;
                if (plain.length > 0) rules += `\n- 추가 핵심 개념: ${plain.join(', ')}`;
                const requiredSections = star[5].length + star[4].length + star[3].length + plain.length;
                if (requiredSections > 0) rules += `\n- ## (Level 2) 헤딩 최소 개수: ${requiredSections}개`;
            } else {
                rules += `\n- 다음 핵심 개념을 반드시 포함하여 교안을 구성하세요: ${keyConcepts.join(', ')}`;
                rules += `\n- ## (Level 2) 헤딩 최소 개수: ${keyConcepts.length}개 (핵심 개념 각각이 최소 1개의 ## 섹션에 대응)`;
            }
        }

        // Self-Correction 체크리스트 (Phase 5-2) + 정량 기준
        rules += '\n\n[자체 검증 체크리스트]\n' +
            '초안 작성 후 아래 8개 관점으로 자체 검토하고 최종본만 출력하세요:\n' +
            '1. 설계 의도 부합성: 차시 목표와 내용이 일관되는가?\n' +
            '2. 대상 수준 적합성: 학습자 수준에 맞는 용어와 설명인가?\n' +
            '3. 사실 기반 여부: 근거 없는 단정이나 추측이 포함되지 않았는가?\n' +
            '4. 분량 기준: 기본 학습(개요+학습목표+핵심내용) 영역은 공백과 서식(마크다운 기호, HTML 태그)을 제외한 순수 텍스트 기준 최소 7,000자를 충족하는가? 기본 실습·심화는 필요한 항목만 포함되면 분량 무관.\n' +
            '5. 서식 준수: 헤딩 위계, 아이콘, 간격, 이미지 태그 규칙을 모두 지켰는가?\n' +
            '6. 구조 연결성: 개요→핵심→실습→심화의 흐름이 자연스러운가?\n' +
            '7. 용어 일관성: 과정/교과/차시/레벨테스트/기본실습 등 glossary 정의와 일치하는가?\n' +
            '8. 서식 워크플로우 준수: 파싱→타이포매핑→아이콘주입→들여쓰기→간격적용→톤적용 순서를 따랐는가?';

        return rules;
    }
    // RAG Lite: 현재 교과의 전체 커리큘럼 목차를 동적 생성 (필요 시에만 주입)
    function getCurriculumOutline() {
        const subj = globalState.subjects.find(s => s.id === currentSubjectId);
        if (!subj || !Array.isArray(subj.lessons) || subj.lessons.length === 0) return '';
        const outline = subj.lessons.map((m, i) => {
            const marker = m.id === 'mainQuest' ? '[MQ]' : `[${i + 1}차시]`;
            return `${marker} ${m.title} - ${m.description || '(설명 없음)'}`;
        }).join('\n');
        return `\n\n[전체 커리큘럼 목차 (맥락 참고용)]\n교과명: ${subj.title}\n${outline}\n\n위 목차의 앞뒤 흐름을 참고하되, 다른 차시와 핵심 내용이 중복되지 않도록 해주세요.`;
    }

    // Thinking Process 프리픽스 (Phase 5-3)
    const thinkingPrefix = '[내부 프로세스] 입력분석→의도검증→구조매핑→집필→자체검증 순서로 수행하세요.\n\n';



    switch (taskScope) {

        case 'blueprint':

            systemInstruction = `${CONTEXT_CORE.personas.orchestrator}\n[규칙]\n- ${CONTEXT_CORE.rules.json_only}\n- ${CONTEXT_CORE.rules.blueprint_scope}`;

            userPrompt = `[현재 작업: 목차 설계]\n주제: ${additionalContext}`;

            break;

        case 'module':

            systemInstruction = `${CONTEXT_CORE.personas.instructor}\n[작성 규칙]\n${buildFullRules(additionalContext.keyConcepts)}`;

            // F2: 분할 생성 지시
            systemInstruction += '\n\n[분량 관리]\n' +
                '- 교안 전체를 한 번에 작성하세요. 단, 출력이 길어져 중간에 잘릴 경우를 대비하여 다음 규칙을 따르세요.\n' +
                '- 모든 섹션을 완전히 작성한 경우: 문서의 맨 마지막에 <!-- END -->를 붙이세요.\n' +
                '- 출력 한도에 도달하여 교안이 미완성인 경우: 자연스러운 문단/섹션 끝에서 멈추고 <!-- CONTINUE -->를 붙이세요. 문장 중간에서 끊지 마세요.';



            if (additionalContext.uploadedMdContent) {

                const safeMd = cleanForAPI(additionalContext.uploadedMdContent);

                userPrompt = `${thinkingPrefix}[현재 작업: 사용자 제공 문서 기반 교안 재구성]\n모듈명: ${additionalContext.title}\n설명: ${additionalContext.description}\n\n[사용자 제공 원본 마크다운 데이터]\n${safeMd}\n\n위 원본 데이터를 철저히 분석하여, 제공된 내용을 바탕으로 우리 교안 규격(1.개요, 2.학습 목표, 3.핵심 내용, 4.실습/예제, 5.심화)에 맞게 다듬고 재구성해 주세요. 원본의 핵심 내용과 의도를 절대 누락하지 말고 최우선으로 반영해야 합니다.`;

            } else {

                userPrompt = `${thinkingPrefix}[현재 작업: 상세 교안 작성]\n모듈명: ${additionalContext.title}\n설명: ${additionalContext.description}`;

            }

            // 커리큘럼 목차 맥락 주입 (앞뒤 흐름 유지 + 중복 방지)
            userPrompt += getCurriculumOutline();



            if (additionalContext.hasMainQuest) {

                systemInstruction += `\n- 차시 내용의 마지막(5번 항목 아래)에는 반드시 배운 내용을 실습할 수 있는 '# ⚔️ 일일 퀘스트 (실습 과제)' 항목을 만들어주세요.`;

                userPrompt += `\n\n[문맥 연동 정보]\n현재 교과의 '메인 퀘스트'가 기획되어 있습니다. 생성할 일일 퀘스트는 아래 메인 퀘스트를 달성하기 위한 징검다리 역할을 해야 합니다.\n- 메인 퀘스트: ${additionalContext.mainQuestText}`;



                if (additionalContext.otherLessonsText) {

                    userPrompt += `\n\n- 다른 차시들의 기존 퀘스트 요약:\n${additionalContext.otherLessonsText}\n\n위 내용들과 중복되지 않고 자연스러운 학습 맥락이 이어지도록 일일 퀘스트를 구성하세요.`;

                }

            } else {

                systemInstruction += `\n- 현재 메인 퀘스트가 설계되지 않았으므로 일일 퀘스트를 절대 생성하지 마세요. 대신 문서의 제일 마지막 줄에 정확히 <!-- 메인 퀘스트가 아직 작성되지 않았습니다. --> 라는 HTML 주석 구문을 하나 추가해 주세요.`;

            }

            break;

        // ── F2: 분할 생성 이어쓰기 케이스 ──
        case 'module_continue':
            systemInstruction = `${CONTEXT_CORE.personas.instructor}\n[작성 규칙]\n${buildFullRules(additionalContext.keyConcepts)}`;
            systemInstruction += '\n\n[이어쓰기 규칙]\n' +
                '- 아래 "이전 작성 내용"의 마지막 부분부터 이어서 작성하세요.\n' +
                '- 이전에 작성한 내용을 절대 반복하지 마세요. 중복 헤딩이나 중복 문단을 생성하면 안 됩니다.\n' +
                '- 이전 내용의 마지막 헤딩/문단을 확인하고, 그 다음 섹션부터 자연스럽게 연결하세요.\n' +
                '- 교안 구조에서 아직 작성되지 않은 남은 섹션을 모두 완성하세요.\n' +
                '- 모든 내용을 마쳤으면 문서 끝에 <!-- END -->를 붙이세요.';

            if (additionalContext.hasMainQuest) {
                systemInstruction += `\n- 차시 내용의 마지막(5번 항목 아래)에는 반드시 '# ⚔️ 일일 퀘스트 (실습 과제)' 항목을 만들어주세요.`;
            }

            userPrompt = `[현재 작업: 교안 이어쓰기 (${additionalContext.chunkIndex}번째 연속)]\n모듈명: ${additionalContext.title}\n설명: ${additionalContext.description}\n\n[이전 작성 내용 — 여기서부터 이어쓰세요]\n${additionalContext.previousContent}`;
            break;

        case 'main_quest':

            systemInstruction = `${CONTEXT_CORE.personas.orchestrator}\n[작성 규칙]\n${buildFullRules()}`;

            userPrompt = `${thinkingPrefix}[현재 작업: 메인 퀘스트(교과 최종 과제) 설계]\n다음은 이 교과에 속한 차시들과 일일 퀘스트 내용입니다. 이를 모두 종합하여, 학습자가 교과 과정을 마스터했는지 평가할 수 있는 흥미로운 '메인 퀘스트' 스토리를 작성해주세요.\n\n차시 정보:\n${additionalContext}`;

            break;

        case 'quiz':

            systemInstruction = `${CONTEXT_CORE.personas.instructor}\n[규칙]\n- ${CONTEXT_CORE.rules.quiz_format}`;

            const compressedText = additionalContext.length > 3000 ? additionalContext.substring(0, 3000) + "...(중략)" : additionalContext;

            userPrompt = `[현재 작업: 퀴즈 출제]\n다음 교안 내용을 바탕으로 퀴즈를 작성하세요:\n\n${cleanForAPI(compressedText)}`;

            break;

        case 'edit':

            systemInstruction = `${CONTEXT_CORE.personas.assistant}\n[규칙]\n- ${CONTEXT_CORE.rules.concise_edit}`;

            userPrompt = `[현재 작업: 텍스트 부분 수정]\n문맥:\n${cleanForAPI(additionalContext.context)}\n\n원본 텍스트:\n${additionalContext.selectedText}\n\n요청사항:\n${additionalContext.command}`;

            break;

        case 'tone':

            systemInstruction = `${CONTEXT_CORE.personas.assistant}\n[규칙]\n- 반드시 한국어로만 작성하세요. 영어로 작성하지 마세요.\n- 마크다운 구조(#, ##, ###, *, - 등)를 원본과 동일하게 유지하세요.\n- <!-- IMG --> 태그, <div>, <img>, <button> 등 모든 HTML 요소는 절대 수정하지 말고 원본 그대로 보존하세요.\n- 텍스트 내용의 문체(톤앤매너)만 변환하고, 핵심 정보와 의미를 누락하지 마세요.\n- ${CONTEXT_CORE.rules.concise_edit}`;

            userPrompt = `[현재 작업: 문체 변환]\n[변환 지시]\n${additionalContext.tonePrompt}\n\n[원본 교안 — 반드시 한국어로 변환 결과를 출력하세요]\n${additionalContext.content}`;

            break;

        case 'volume':

            systemInstruction = `${CONTEXT_CORE.personas.assistant}\n[규칙]\n- 반드시 한국어로만 작성하세요. 영어로 작성하지 마세요.\n- 마크다운 구조(#, ##, ###, *, - 등)를 원본과 동일하게 유지하세요.\n- <!-- IMG --> 태그, <div>, <img>, <button> 등 모든 HTML 요소는 절대 수정하지 말고 원본 그대로 보존하세요.\n- 텍스트 분량만 조절하고, 핵심 정보와 의미를 누락하지 마세요.\n- ${CONTEXT_CORE.rules.concise_edit}`;

            userPrompt = `[현재 작업: 분량 조절]\n[조절 지시]\n${additionalContext.volumePrompt}\n\n[원본 교안 — 반드시 한국어로 조절 결과를 출력하세요]\n${additionalContext.content}`;

            break;

    }



    return { systemInstruction, userPrompt };
}
